 class Node {
   
    int value;
    Node nextNode;
    Node prevNode;

    public Node(int data) {
        value = data;
        nextNode = null;
        prevNode = null;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int data) {
        value = data;
    }

    public Node getNextNode() {
        return nextNode;
    }

    public void setNextNode(Node n) {
        nextNode = n;
    }

    public Node getPrevNode() {
        return prevNode;
    }

    public void setPrevNode(Node n) {
        prevNode = n;
    }

}

